package com.oirs.service;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;

public interface IAuthenticateService {
	public userBean loginUser(String userId,String userPass) throws OIRSException;
}
