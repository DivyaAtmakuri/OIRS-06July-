package com.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;
import com.oirs.util.DBConnection;

public class AuthenticateDAOImpl implements IAuthenticateDAO {

	Connection connection = null;
	
	@Override
	public userBean loginUser(String userId, String userPass)
			throws OIRSException {
		new DBConnection();
		// TODO Auto-generated method stub
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		userBean bean = new userBean();
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_AUTH_USER);
			preparedStatement.setString(1, userId);
			preparedStatement.setString(2, userPass);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){

				bean.setUserId(resultSet.getString(1));
				bean.setUserRole(resultSet.getString(2));
				bean.setLastLogin(resultSet.getString(3));
				
			}
			else
			{
				bean = null;	
			}
			return bean;
			
		} catch (SQLException e) {
			throw new OIRSException("Auth SQL Exception : "+e.getMessage());
		}
		
	}

}
