package com.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.exception.OIRSException;
import com.oirs.util.DBConnection;

public class RMGEDAOImpl implements IRMGEDAO {
	Connection connection = null;
	@Override
	public List<EmployeeBean> searchEmployee(RequisitionBean reqBean)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<EmployeeBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		String skill = reqBean.getReqSkill();
		System.out.println(skill);
		String domain = reqBean.getReqDomain();
		System.out.println(domain);
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_SEARCH_EMPLOYEE);
			preparedStatement.setString(1, skill);
			preparedStatement.setString(2, domain);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()){
				EmployeeBean bean = new EmployeeBean();
				bean.setEmpId(resultSet.getString(1));
				bean.setEmpName(resultSet.getString(2));
				bean.setEmpSkill(resultSet.getString(3));
				bean.setEmpDomain(resultSet.getString(4));
				bean.setEmpExp(resultSet.getInt(5));
				bean.setEmpProjectId(resultSet.getString(6));
				list.add(bean);
				System.out.println(resultSet.getString(2));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public List<String> getRmIds() throws OIRSException {
		// TODO Auto-generated method stub
		connection = DBConnection.getConnection();
		List<String> list = new ArrayList<>();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_GET_RM_IDS);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				System.out.println(resultSet.getString(1));
				list.add(resultSet.getString(1));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public List<RequisitionBean> getAllRequisitions() throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_GET_ALL_REQ);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				//requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required
				RequisitionBean bean = new RequisitionBean();
				System.out.println(resultSet.getString(1));
				bean.setReqId(resultSet.getString(1));
				bean.setReqRmId(resultSet.getString(2));
				bean.setReqProjectId(resultSet.getString(3));
				bean.setReqDateCreated(resultSet.getString(4));
				bean.setReqDateClosed(resultSet.getString(5));
				bean.setReqStatus(resultSet.getString(6));
				bean.setReqVacancyName(resultSet.getString(7));
				bean.setReqSkill(resultSet.getString(8));
				bean.setReqDomain(resultSet.getString(9));
				bean.setReqNoReq(resultSet.getInt(10));
				list.add(bean);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
 		return list;
	}

	@Override
	public RequisitionBean getRequisitionDetails(String reqId)
			throws OIRSException {
		// TODO Auto-generated method stub
		
		//List<RequisitionBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		RequisitionBean bean = null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_GET_REQ_BY_REQID);
			preparedStatement.setString(1, reqId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				bean = new RequisitionBean();
				//requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required	
				System.out.println(resultSet.getString(1));
				bean.setReqId(resultSet.getString(1));
				bean.setReqRmId(resultSet.getString(2));
				bean.setReqProjectId(resultSet.getString(3));
				bean.setReqDateCreated(resultSet.getString(4));
				bean.setReqDateClosed(resultSet.getString(5));
				bean.setReqStatus(resultSet.getString(6));
				bean.setReqVacancyName(resultSet.getString(7));
				bean.setReqSkill(resultSet.getString(8));
				bean.setReqDomain(resultSet.getString(9));
				bean.setReqNoReq(resultSet.getInt(10));
				//list.add(bean);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
 		return bean;
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatus(String status)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_VIEW_REQUISITION_BY_STATUS);
			preparedStatement.setString(1, status);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				//requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required
				RequisitionBean bean = new RequisitionBean();
				System.out.println(resultSet.getString(1));
				bean.setReqId(resultSet.getString(1));
				bean.setReqRmId(resultSet.getString(2));
				bean.setReqProjectId(resultSet.getString(3));
				bean.setReqDateCreated(resultSet.getString(4));
				bean.setReqDateClosed(resultSet.getString(5));
				bean.setReqStatus(resultSet.getString(6));
				bean.setReqVacancyName(resultSet.getString(7));
				bean.setReqSkill(resultSet.getString(8));
				bean.setReqDomain(resultSet.getString(9));
				bean.setReqNoReq(resultSet.getInt(10));
				list.add(bean);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
 		return list;
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatusRM(String rmId,
			String status) throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_VIEW_REQUISITION_BY_STATUS);
			preparedStatement.setString(1, rmId);
			preparedStatement.setString(2, status);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				//requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required
				RequisitionBean bean = new RequisitionBean();
				System.out.println(resultSet.getString(1));
				bean.setReqId(resultSet.getString(1));
				bean.setReqRmId(resultSet.getString(2));
				bean.setReqProjectId(resultSet.getString(3));
				bean.setReqDateCreated(resultSet.getString(4));
				bean.setReqDateClosed(resultSet.getString(5));
				bean.setReqStatus(resultSet.getString(6));
				bean.setReqVacancyName(resultSet.getString(7));
				bean.setReqSkill(resultSet.getString(8));
				bean.setReqDomain(resultSet.getString(9));
				bean.setReqNoReq(resultSet.getInt(10));
				list.add(bean);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
 		return list;
	}

	@Override
	public List<RequisitionBean> getRequisitionByRMId(String rmId)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_GET_REQ_RMID);
			preparedStatement.setString(1, rmId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				//requisition_id,rm_id,project_id,date_created,date_closed,current_status,vacancy_name,skill,domain,number_required
				RequisitionBean bean = new RequisitionBean();
				System.out.println(resultSet.getString(1));
				bean.setReqId(resultSet.getString(1));
				bean.setReqRmId(resultSet.getString(2));
				bean.setReqProjectId(resultSet.getString(3));
				bean.setReqDateCreated(resultSet.getString(4));
				bean.setReqDateClosed(resultSet.getString(5));
				bean.setReqStatus(resultSet.getString(6));
				bean.setReqVacancyName(resultSet.getString(7));
				bean.setReqSkill(resultSet.getString(8));
				bean.setReqDomain(resultSet.getString(9));
				bean.setReqNoReq(resultSet.getInt(10));
				list.add(bean);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
 		return list;
	}

	@Override
	public boolean assignProject(String empId, String reqId)
			throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = false;
		connection = DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.QUERY_ASSIGN_PROJECT);
			preparedStatement.setString(1, reqId);
			preparedStatement.setString(2, empId);
			int queryResult = preparedStatement.executeUpdate();
			if(queryResult!=0){
				result = true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public void generateReport() throws OIRSException {
		// TODO Auto-generated method stub

	}

}
