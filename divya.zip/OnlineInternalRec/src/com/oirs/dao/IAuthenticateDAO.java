package com.oirs.dao;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;

public interface IAuthenticateDAO {
	public userBean loginUser(String userId,String userPass) throws OIRSException;
}
