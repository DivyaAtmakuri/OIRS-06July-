package com.oirs.dao;

import java.util.List;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;

public interface IAdminDAO {
	public String addNewUser(userBean userBean) throws OIRSException;
	public String assignRole(String userId,String role) throws OIRSException;
	public String deleteUser(String userId) throws OIRSException;	
	public List<String> getUserIds() throws OIRSException;
	public void generateReport() throws OIRSException;
}
